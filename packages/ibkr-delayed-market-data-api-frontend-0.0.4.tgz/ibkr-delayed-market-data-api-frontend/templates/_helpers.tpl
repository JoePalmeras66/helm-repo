{{- define "ibkr-delayed-market-data-api-frontend.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "ibkr-delayed-market-data-api-frontend.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{- define "ibkr-delayed-market-data-api-frontend.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "ibkr-delayed-market-data-api-frontend.labels" -}}
helm.sh/chart: {{ include "ibkr-delayed-market-data-api-frontend.chart" . }}
{{ include "ibkr-delayed-market-data-api-frontend.selectorLabels" . }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{- define "ibkr-delayed-market-data-api-frontend.selectorLabels" -}}
app.kubernetes.io/name: {{ include "ibkr-delayed-market-data-api-frontend.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "ibkr-delayed-market-data-api-frontend.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "ibkr-delayed-market-data-api-frontend.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}
