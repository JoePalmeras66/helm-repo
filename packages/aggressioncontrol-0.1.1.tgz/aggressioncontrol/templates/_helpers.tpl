{{/*
_helpers.tpl — named template definitions for the aggressioncontrol Helm chart
*/}}

{{/*
Expand the name of the chart.
*/}}
{{- define "aggressioncontrol.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
Truncates at 63 characters (Kubernetes label value limit).
If release name already contains the chart name, use the release name alone.
*/}}
{{- define "aggressioncontrol.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version label value, e.g. aggressioncontrol-0.1.0.
Hyphens replace plus signs so the value is a valid Kubernetes label.
*/}}
{{- define "aggressioncontrol.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Standard Helm labels applied to all resources managed by this chart.
*/}}
{{- define "aggressioncontrol.labels" -}}
helm.sh/chart: {{ include "aggressioncontrol.chart" . }}
{{ include "aggressioncontrol.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels — used in Service selectors and PodDisruptionBudget selectors.
Subset of standard labels; must be stable (never change after initial install).
*/}}
{{- define "aggressioncontrol.selectorLabels" -}}
app.kubernetes.io/name: {{ include "aggressioncontrol.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
ServiceAccount name: use explicitly configured name if set, otherwise use fullname.
*/}}
{{- define "aggressioncontrol.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "aggressioncontrol.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}
